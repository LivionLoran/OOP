# Graphics editor

by Ralovets

## Functionality

### Drawing shapes. You can draw...

* Line
* Circle
* Ellipse
* Rectangle
* Square
* Triangle
    
### Working with files. You can...

* Create new project file
* Open project from file
* Save project into file
