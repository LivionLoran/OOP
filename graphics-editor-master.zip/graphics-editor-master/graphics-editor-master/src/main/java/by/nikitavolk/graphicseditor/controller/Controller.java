package by.nikitavolk.graphicseditor.controller;

import by.nikitavolk.graphicseditor.Main;
import by.nikitavolk.graphicseditor.serviceinfo.*;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

public class Controller {

    private ShapesList shapes = new ShapesList();
    private ShapeInitializer shapeInitializer;
    private ClassReader classes = new ClassReader();

    @FXML
    private void initialize() {
        classes.load();
        shapeInitializer = new ShapeInitializer(classes);

        // Заполнить список фигур
        toolsList.setItems(FXCollections.observableArrayList(classes.getNames()));
        toolsList.setValue(classes.getNames().get(0));

        // Слушатель на выбор инструмента
        toolsList.getSelectionModel().selectedIndexProperty().addListener((ov, value, new_value) -> {
            shapeInitializer.refresh(classes.getNames().get((Integer) new_value));
        });

        shapeInitializer.refresh(classes.getNames().get(0));
    }

    @FXML
    private void onCanvasClicked(MouseEvent mouseEvent) {
        try {
            shapeInitializer.addPoint(new Point(mouseEvent.getX(), mouseEvent.getY()));

            if (shapeInitializer.readyToDraw()) {
                Shape shape = shapeInitializer.getReadyShape(getStyle());
                shape.draw(canvas.getGraphicsContext2D());
                shapes.add(shape);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void onClearClicked(MouseEvent mouseEvent) {
        clearScreen();
        shapes.clear();
        shapeInitializer.refresh(toolsList.getValue());
    }

    @FXML
    private void onMenuOpenClicked(ActionEvent actionEvent) {
        final FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showOpenDialog(Main.stage);

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            // Считать имя первой фигуры
            String line = reader.readLine();

            if (!classes.getNames().contains(line)) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Фигуры, находящейся в файле, не существует!");
                alert.showAndWait();
                return;
            }

            shapes.clear();

            while (line != null) {
                String _name = line;
                PointsList _points = new PointsList();
                Style _style = null;

                while (!line.isEmpty()) {
                    // Пустая строка
                    reader.readLine();

                    // Чтение точек фигуры
                    line = reader.readLine();
                    while (!line.isEmpty()) {
                        _points.add(new Point(
                                Double.parseDouble(line),
                                Double.parseDouble(reader.readLine())
                        ));
                        line = reader.readLine();
                    }

                    // *была считана пустая строка-разделитель*

                    // Чтение стиля
                    line = reader.readLine();
                    _style = new Style(
                            Double.parseDouble(line),
                            new javafx.scene.paint.Color(
                                    Double.parseDouble(reader.readLine()),
                                    Double.parseDouble(reader.readLine()),
                                    Double.parseDouble(reader.readLine()),
                                    Double.parseDouble(reader.readLine())
                            ),
                            new javafx.scene.paint.Color(
                                    Double.parseDouble(reader.readLine()),
                                    Double.parseDouble(reader.readLine()),
                                    Double.parseDouble(reader.readLine()),
                                    Double.parseDouble(reader.readLine())
                            )
                    );

                    // Пустая строка
                    line = reader.readLine();
                }

                // Создать фигуру, добавить в список
                Shape shape = (Shape) classes.getConstructor(_name).newInstance(
                        _points.clone(), _style
                );
                shapes.add(shape);

                // Название фигуры или ничего
                line = reader.readLine();
            }
            clearScreen();
            shapeInitializer.refresh(toolsList.getValue());
        } catch (Exception e) {
            return;
        } finally {
            for (Shape shape : shapes.getShapes()) {
                shape.draw(canvas.getGraphicsContext2D());
            }
        }
    }

    @FXML
    private void onMenuSaveClicked(ActionEvent actionEvent) {
        final FileChooser fileChooser = new FileChooser();
        File file = fileChooser.showSaveDialog(Main.stage);
        shapes.saveToFile(file);
    }

    @FXML
    public void onMenuClearClicked(ActionEvent actionEvent) {
        clearScreen();
        shapes.clear();
        shapeInitializer.refresh(toolsList.getValue());
    }

    @FXML
    private void onMenuAddPluginClicked(ActionEvent actionEvent) throws Exception {
        final FileChooser chooser = new FileChooser();
        File f = chooser.showOpenDialog(Main.stage);

    }

    private Style getStyle() {
        return new Style(
                borderWidth.getValue(),
                borderColorChoice.getValue(),
                fillColorChoise.getValue()
        );
    }

    private void clearScreen() {
        GraphicsContext eraser = canvas.getGraphicsContext2D();
        eraser.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
    }

    @FXML
    private ColorPicker borderColorChoice;

    @FXML
    private ColorPicker fillColorChoise;

    @FXML
    private Slider borderWidth;

    @FXML
    private Canvas canvas;

    @FXML
    private ChoiceBox<String> toolsList;
}
