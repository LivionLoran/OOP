package by.nikitavolk.graphicseditor.serviceinfo;

import io.github.classgraph.ClassGraph;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class ClassReader {

    private final String path = "by.ralovets.graphicseditor.serviceinfo.Shape";
    private ArrayList<String> names = new ArrayList<String>();
    private List<Class<?>> classes;
    private ArrayList<Constructor> constructors = new ArrayList<Constructor>();
    private ArrayList<Integer> fields = new ArrayList<Integer>();

    public Class getClass(String toolName) {
        for (int i = 0; i < names.size(); i++) {
            if (names.get(i).equals(toolName)) {
                return classes.get(i);
            }
        }
        return null;
    }

    public int getPointsCount(String toolName) {
        Class c = getClass(toolName);
        try {
            Field field = c.getDeclaredField("DOTS");
            field.setAccessible(true);
            int i = (Integer) field.get(null);
            return i;
        } catch (Exception e) {
            return -1;
        }
    }

    public Constructor getConstructor(String toolName) {
        Class c = getClass(toolName);
        try {
            return c.getConstructor(new Class[]{PointsList.class, Style.class});
        } catch (Exception e) {
            return null;
        }
    }

    public ArrayList<String> getNames() {
        return names;
    }

    public void load() {
        classes = new ClassGraph()
                .enableAllInfo()
                .scan()
                .getSubclasses(path)
                .loadClasses();

        for (Class c : classes) {
            names.add(c.getSimpleName());
        }
    }
}
