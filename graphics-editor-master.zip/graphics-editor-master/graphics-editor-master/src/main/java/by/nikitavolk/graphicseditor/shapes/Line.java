package by.nikitavolk.graphicseditor.shapes;

import by.nikitavolk.graphicseditor.serviceinfo.Point;
import by.nikitavolk.graphicseditor.serviceinfo.PointsList;
import by.nikitavolk.graphicseditor.serviceinfo.Shape;
import by.nikitavolk.graphicseditor.serviceinfo.Style;
import javafx.scene.canvas.GraphicsContext;

import java.util.ArrayList;

public class Line extends Shape {

    final static private int DOTS = 2;
    final private int TOP_LEFT = 0;
    final private int BOTTOM_RIGHT = 1;

    private ArrayList<Point> points;
    private Point startPoint;
    private Point endPoint;

    public void draw(GraphicsContext pen) {
        pen.setLineWidth(style.getBorderWidth());
        pen.setFill(style.getFillColor());
        pen.setStroke(style.getBorderColor());

        pen.strokeLine(
                startPoint.getX(),
                startPoint.getY(),
                endPoint.getX(),
                endPoint.getY()
        );
    }

    public Line(PointsList points, Style style) {
        super(points, style);

        calculateValues(points.get(TOP_LEFT), points.get(BOTTOM_RIGHT));
    }

    private void calculateValues(Point startPoint, Point endPoint) {
        this.startPoint = startPoint;
        this.endPoint = endPoint;
    }
}
