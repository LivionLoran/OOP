package by.nikitavolk.graphicseditor.serviceinfo;

public class ShapeInitializer {

    private ClassReader classes;
    private String shapeName;
    private PointsList points = new PointsList();
    private int pointsNeed = -1;
    private int pointsCount = 0;

    public ShapeInitializer(ClassReader classes) {
        this.classes = classes;
    }

    public void refresh(String newShapeName) {
        shapeName = newShapeName;
        pointsNeed = classes.getPointsCount(newShapeName);
        points.clear();
    }

    public boolean readyToDraw() {
        return pointsCount == pointsNeed;
    }

    public void addPoint(Point point) {
        points.add(point);
        pointsCount++;
    }

    public Shape getReadyShape(Style style) throws Exception {
        Shape shape = (Shape) classes.getConstructor(shapeName).newInstance(
                points.clone(), style
        );
        refresh(shapeName);
        pointsCount = 0;
        return shape;
    }
}
