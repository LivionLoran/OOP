package by.nikitavolk.graphicseditor.serviceinfo;

import javafx.scene.control.Alert;
import java.io.*;
import java.util.ArrayList;

public class ShapesList {

    ArrayList<Shape> shapes = new ArrayList<Shape>();

    public ArrayList<Shape> getShapes() {
        return shapes;
    }

    public ShapesList() {
    }


    public int size() {
        return shapes.size();
    }

    public void add(Shape shape) {
        shapes.add(shape);
    }

    public void clear() {
        shapes.clear();
    }

    public void saveToFile(File file) {

        try {
            FileWriter fileWriter = new FileWriter(file);

            for (Shape shape : shapes)
                fileWriter.write(shape.toString());

            fileWriter.close();

        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setHeaderText("File didn't save");
            alert.setContentText("File didn't save. Check your acces to file and try again!");
            alert.showAndWait();
        }
    }
}
