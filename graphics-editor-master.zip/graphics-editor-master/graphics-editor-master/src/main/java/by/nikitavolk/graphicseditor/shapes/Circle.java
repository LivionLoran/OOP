package by.nikitavolk.graphicseditor.shapes;

import by.nikitavolk.graphicseditor.serviceinfo.Point;
import by.nikitavolk.graphicseditor.serviceinfo.PointsList;
import by.nikitavolk.graphicseditor.serviceinfo.Shape;
import by.nikitavolk.graphicseditor.serviceinfo.Style;
import javafx.scene.canvas.GraphicsContext;

public class Circle extends Shape {

    final static private int DOTS = 2;
    final private int CENTER = 0;
    final private int REMOTE = 1;

    private Point center;
    private double radius;
    private double diameter;

    public void draw(GraphicsContext pen) {
        pen.setLineWidth(style.getBorderWidth());
        pen.setFill(style.getFillColor());
        pen.setStroke(style.getBorderColor());

        pen.strokeOval(
                center.getX() - radius,
                center.getY() - radius,
                diameter,
                diameter
        );

        pen.fillOval(
                center.getX() - radius,
                center.getY() - radius,
                diameter,
                diameter
        );
    }

    public Circle(PointsList points, Style style) {
        super(points, style);

        calculateValues(points.get(CENTER), points.get(REMOTE));
    }

    private void calculateValues(Point center, Point remote) {
        double horisontalDistance = Math.abs(center.getX() - remote.getX());
        double verticalDistance = Math.abs(center.getY() - remote.getY());
        this.center = center;

        radius = Math.sqrt(
                Math.pow(horisontalDistance, 2) +Math.pow(verticalDistance, 2)
        );

        diameter = radius * 2;
    }
}