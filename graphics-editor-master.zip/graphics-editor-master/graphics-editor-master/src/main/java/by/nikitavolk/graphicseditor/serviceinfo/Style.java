package by.nikitavolk.graphicseditor.serviceinfo;

import javafx.scene.paint.Color;

public class Style {
    private Color borderColor = new Color(0, 0, 0, 1);
    private Color fillColor = new Color(0, 0, 0, 0);
    private double borderWidth = 2;

    public Color getBorderColor() {
        return borderColor;
    }

    public Color getFillColor() {
        return fillColor;
    }

    public double getBorderWidth() {
        return borderWidth;
    }

    public Style(double borderWidth, Color borderColor, Color fillColor) {
        this.borderColor = borderColor;
        this.fillColor = fillColor;
        this.borderWidth = borderWidth;
    }

    @Override
    public String toString() {

        return borderWidth + "\n" +
                borderColor.getRed() + "\n" +
                borderColor.getGreen() + "\n" +
                borderColor.getBlue() + "\n" +
                borderColor.getOpacity() + "\n"+
                fillColor.getRed() + "\n" +
                fillColor.getGreen() + "\n" +
                fillColor.getBlue() + "\n" +
                fillColor.getOpacity() + "\n";
    }
}
