package by.nikitavolk.graphicseditor.serviceinfo;

import java.util.ArrayList;

public class PointsList extends ArrayList<Point> {

    public PointsList() {
        super();
    }

}