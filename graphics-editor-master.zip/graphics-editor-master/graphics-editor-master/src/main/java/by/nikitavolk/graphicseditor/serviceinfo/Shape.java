package by.nikitavolk.graphicseditor.serviceinfo;

import javafx.scene.canvas.GraphicsContext;

public abstract class Shape {

    public abstract void draw(GraphicsContext pen);

    protected Style style;
    private String className = this.getClass().asSubclass(Shape.class).getSimpleName();
    protected PointsList points;

    public Shape(PointsList points, Style style) {
        this.style = style;
        this.points = points;
    }

    @Override
    public String toString() {
        String result = className + "\n\n";

        for (Point point : points) {
            result += point.getX() + "\n";
            result += point.getY() + "\n";
        }
        result += "\n";

        result += style.toString() + "\n";
        return result;
    }
}
