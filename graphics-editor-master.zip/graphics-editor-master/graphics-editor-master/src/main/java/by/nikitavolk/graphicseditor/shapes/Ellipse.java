package by.nikitavolk.graphicseditor.shapes;

import by.nikitavolk.graphicseditor.serviceinfo.Point;
import by.nikitavolk.graphicseditor.serviceinfo.PointsList;
import by.nikitavolk.graphicseditor.serviceinfo.Shape;
import by.nikitavolk.graphicseditor.serviceinfo.Style;
import javafx.scene.canvas.GraphicsContext;

import java.util.ArrayList;

public class Ellipse extends Shape {

    final static private int DOTS = 2;
    final private int TOP_LEFT = 0;
    final private int BOTTOM_RIGHT = 1;

    private ArrayList<Point> points;
    private Point center;
    private double verticalRadius;
    private double horizontalRadius;
    private double verticalDiameter;
    private double horizontalDiameter;

    public void draw(GraphicsContext pen) {
        pen.setLineWidth(style.getBorderWidth());
        pen.setFill(style.getFillColor());
        pen.setStroke(style.getBorderColor());

        pen.strokeOval(
                center.getX() - horizontalRadius,
                center.getY() - verticalRadius,
                horizontalDiameter,
                verticalDiameter
        );

        pen.fillOval(
                center.getX() - horizontalRadius,
                center.getY() - verticalRadius,
                horizontalDiameter,
                verticalDiameter
        );
    }

    public Ellipse(PointsList points, Style style) {
        super(points, style);

        calculateValues(points.get(TOP_LEFT), points.get(BOTTOM_RIGHT));
    }

    private void calculateValues(Point topLeft, Point bottomRight) {
        horizontalDiameter = Math.abs(topLeft.getX() - bottomRight.getX());
        horizontalRadius = horizontalDiameter / 2;

        verticalDiameter = Math.abs(topLeft.getY() - bottomRight.getY());
        verticalRadius = verticalDiameter / 2;

        double topLeftX;
        double topLeftY;
        if (topLeft.getX() < bottomRight.getX()) {
            topLeftX = topLeft.getX();
            if (topLeft.getY() > bottomRight.getY()) {
                topLeftY = bottomRight.getY();
            } else {
                topLeftY = topLeft.getY();
            }
        } else {
            topLeftX = bottomRight.getX();
            if (bottomRight.getY() > topLeft.getY()) {
                topLeftY = topLeft.getY();
            } else {
                topLeftY = bottomRight.getY();
            }
        }

        center = new Point(
                topLeftX + horizontalRadius,
                topLeftY + verticalRadius
        );
    }
}