package by.nikitavolk.graphicseditor.shapes;

import by.nikitavolk.graphicseditor.serviceinfo.Point;
import by.nikitavolk.graphicseditor.serviceinfo.PointsList;
import by.nikitavolk.graphicseditor.serviceinfo.Shape;
import by.nikitavolk.graphicseditor.serviceinfo.Style;
import javafx.scene.canvas.GraphicsContext;

import java.util.ArrayList;

public class Triangle extends Shape {

    final static private int DOTS = 3;
    final private int BASE_1 = 0;
    final private int BASE_2 = 1;
    final private int TOP = 2;

    private ArrayList<Point> points;
    private Point top;
    private Point base1;
    private Point base2;

    public void draw(GraphicsContext pen) {
        pen.setLineWidth(style.getBorderWidth());
        pen.setFill(style.getFillColor());
        pen.setStroke(style.getBorderColor());

        pen.strokePolygon(
                new double[] {base1.getX(), base2.getX(), top.getX()},
                new double[] {base1.getY(), base2.getY(), top.getY()},
                3
        );

        pen.fillPolygon(
                new double[] {base1.getX(), base2.getX(), top.getX()},
                new double[] {base1.getY(), base2.getY(), top.getY()},
                3
        );
    }

    public Triangle(PointsList points, Style style) {
        super(points, style);

        calculateValues(
                points.get(BASE_1),
                points.get(BASE_2),
                points.get(TOP)
        );
    }

    private void calculateValues(Point base1, Point base2, Point top) {
        this.base1 = base1;

        this.base2 = new Point(
                base2.getX(),
                base1.getY()
        );

        this.top = top;
    }
}
