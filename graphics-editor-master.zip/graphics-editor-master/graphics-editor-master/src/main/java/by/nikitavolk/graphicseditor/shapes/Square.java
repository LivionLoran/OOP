package by.nikitavolk.graphicseditor.shapes;

import by.nikitavolk.graphicseditor.serviceinfo.Point;
import by.nikitavolk.graphicseditor.serviceinfo.PointsList;
import by.nikitavolk.graphicseditor.serviceinfo.Shape;
import by.nikitavolk.graphicseditor.serviceinfo.Style;
import javafx.scene.canvas.GraphicsContext;

import java.util.ArrayList;

public class Square extends Shape {

    final static private int DOTS = 2;
    final private int TOP_LEFT = 0;
    final private int BOTTOM_RIGHT = 1;

    private ArrayList<Point> points;
    private Point startPoint;
    private double width;

    public void draw(GraphicsContext pen) {
        pen.setLineWidth(style.getBorderWidth());
        pen.setFill(style.getFillColor());
        pen.setStroke(style.getBorderColor());

        pen.strokeRect(
                startPoint.getX(),
                startPoint.getY(),
                width,
                width
        );

        pen.fillRect(
                startPoint.getX(),
                startPoint.getY(),
                width,
                width
        );
    }

    public Square(PointsList points, Style style) {
        super(points, style);

        calculateValues(points.get(TOP_LEFT), points.get(BOTTOM_RIGHT));
    }

    private void calculateValues(Point topLeft, Point bottomRight) {
        width = Math.min(
                Math.abs(topLeft.getX() - bottomRight.getX()),
                Math.abs(topLeft.getY() - bottomRight.getY())
        );

        double topLeftX;
        double topLeftY;
        if (topLeft.getX() < bottomRight.getX()) {
            topLeftX = topLeft.getX();
            if (topLeft.getY() > bottomRight.getY()) {
                topLeftY = bottomRight.getY();
            } else {
                topLeftY = topLeft.getY();
            }
        } else {
            topLeftX = bottomRight.getX();
            if (bottomRight.getY() > topLeft.getY()) {
                topLeftY = topLeft.getY();
            } else {
                topLeftY = bottomRight.getY();
            }
        }

        this.startPoint = new Point(
                topLeftX,
                topLeftY
        );
    }
}
